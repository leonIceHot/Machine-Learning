# -*- coding: utf-8 -*-
"""
Created on Mon Aug  5 15:08:10 2019

@author: USER
"""
import matplotlib.pyplot as plt

Students = [2,4,6,8,10]
Courses  = [4,5,3,2,3]
stds     = [3,5,7,9,11]
Projects = [1,2,4,3,2]
plt.bar(Students, Courses, label="Courses", color='r')
plt.bar(stds, Projects, label="Projects", color='c')
plt.xlabel('Students')
plt.ylabel('Courses/Projects')
plt.title('Students Courses and Projects Data\n 2018')
plt.legend()
plt.show()