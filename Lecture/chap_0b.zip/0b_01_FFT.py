# -*- coding: utf-8 -*-
"""
Created on Tue Aug  6 17:31:12 2019

@author: USER
"""

import matplotlib.pyplot as plt
import numpy as np

t  = np.linspace(0, 120, 4000)
PI = np.pi
f1 = 3
f2 = 8

signal = 12*np.sin(2*PI*f1*t) 			# 3 Hz
signal += 6*np.sin(2*PI*f2*t) 			# 8 Hz
signal += 1.5*np.random.random(len(t)) 	# noise

# Time-domain plot
plt.style.use('classic')
fig, ax = plt.subplots()
plt.plot(t, signal, color='SteelBlue')
plt.grid()
ax.axis('equal')
plt.xlabel('t(sec)')
plt.ylabel('f(t)')
plt.show()

# FFT transformation
FFT = abs(np.fft.fft(signal))
freqs = np.fft.fftfreq(signal.size, t[1]-t[0])

# Frequency plot
plt.style.use('classic')
fig, ax = plt.subplots()
plt.plot(freqs, FFT, color='IndianRed')
plt.grid()
plt.xlabel('frequency(Hz)')
plt.ylabel('Amplitude')
plt.show()