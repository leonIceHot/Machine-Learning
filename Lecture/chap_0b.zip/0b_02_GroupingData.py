# -*- coding: utf-8 -*-
"""
Created on Fri Aug  9 19:53:27 2019

@author: USER
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.DataFrame({'A' : ['foo','bar','foo','bar','foo','bar','foo','foo'],
                   'B' : ['one','one','two','three','two','two','one','three'],
                   'C' : np.random.randn(8),
                   'D' : np.random.randn(8)})
print(df)

# Group by either A or B columns or both
groupedA  = df.groupby('A')
print('\n')
print(list(groupedA))
groupedAB = df.groupby(['A', 'B'])
print('\n')
print(list(groupedAB))

# Get statistics for groupedA and groupedAB
print('\n')
print(groupedA.size())
print('\n')
print(groupedAB.size())

print('\n')
print(groupedA.describe())
print('\n')
print(groupedAB.describe())

print('\n')
print(groupedA.count())
print('\n')
print(groupedAB.count())

# Visually inspecting the grouping
w = groupedA['C'].agg([np.sum, np.mean]).plot()
plt.show()

