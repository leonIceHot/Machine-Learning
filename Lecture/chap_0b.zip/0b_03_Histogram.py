# -*- coding: utf-8 -*-
"""
Created on Mon Aug  5 15:19:32 2019

@author: USER
"""
import matplotlib.pyplot as plt

Ages = [22.5, 10, 55, 8, 62, 45, 21, 34, 
        42, 45, 99, 75, 82, 77, 55, 43, 
        66, 66, 78, 89, 101, 34, 65, 56,
        25, 34, 52, 25, 63, 37, 32]
binsx = [0, 10, 20, 30, 40, 50, 60, 70, 
         80, 90, 100, 110]

plt.hist(Ages, bins=binsx, histtype='bar', 
         rwidth=0.7)
plt.xlabel('Ages')
plt.ylabel('Frequency')
plt.title('Ages frequency for sample ' +
          'pouplation\n 2018')
plt.show()