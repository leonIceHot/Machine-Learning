# -*- coding: utf-8 -*-
"""
Created on Fri Aug  9 11:13:47 2019

@author: USER
"""
import numpy as np
import time

def python_version():
    t1 = time.time()
    X  = range(10000000)
    Y  = range(10000000)
    Z  = []
    for i in range(len(X)):
        Z.append(X[i] + Y[i])
    return time.time() - t1 

def numpy_version():
    t1 = time.time()
    X  = np.arange(10000000)
    Y  = np.arange(10000000)
    Z  = X + Y
    return time.time() - t1

dt1 = python_version()
print("Time for calling python_version() " + 
      "is {0:.5f}\n".format(dt1))
dt2 = numpy_version()
print("Time for calling numpy_version() " +
      "is {0:.5f}\n".format(dt2))