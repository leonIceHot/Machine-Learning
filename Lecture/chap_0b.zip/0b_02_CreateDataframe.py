# -*- coding: utf-8 -*-
"""
Created on Fri Aug  9 11:48:39 2019

@author: USER
"""

import pandas as pd

d = {'one': pd.Series([1., 2., 3.],
            index=['a', 'b', 'c']),
    'two' : pd.Series([1., 2., 3., 4.], 
           index=['a', 'b', 'c', 'd']) }
df = pd.DataFrame(d)
print(df)

names = ['Bob','Jessica','Mary','John','Mel']
births = [968 , 155 , 77, 578 , 973]
BabyDataSet = list(zip(names, births))
for i in range(len(births)):
    print(BabyDataSet[i])

# Pandas - Create a data frame and write to a csv file
df = pd.DataFrame(data=BabyDataSet, columns=['Names', 'Births'])
df.to_csv('births1880.csv', index=False, header=False)   

# Pandas - Read data from a file
fileName = 'births1880.csv'
df = pd.read_csv(fileName, names=['Names', 'Births'])

# Pandas - Add a column
d = [1,2,3,4,5]
df['Rev'] = d

# Pandas - Change indices
idx = ['a','b','c','d','e']
df.index = idx
