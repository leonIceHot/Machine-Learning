# -*- coding: utf-8 -*-
"""
Created on Mon Aug  5 17:29:09 2019

@author: USER
"""

import seaborn as sns

iris = sns.load_dataset("iris")
iris.head()
sns.pairplot(iris, hue='species', size=2.5)

tips = sns.load_dataset('tips')
tips.head()