# -*- coding: utf-8 -*-
"""
Created on Sun Aug  4 07:46:03 2019
@author: USER
"""

import matplotlib.pyplot as plt
import numpy as np

plt.style.use('classic')

x       = np.linspace(-6, 6, 100)
fig, ax = plt.subplots()
plt.plot(x, np.sin(x), '.', 
         color='SteelBlue', label='Sine')
plt.plot(x, np.cos(x), '-', 
         color='RosyBrown', label='Cosine')
ax.axis('equal')
plt.grid()
plt.xlabel('x')
plt.ylabel('y')
plt.legend(loc='best', shadow=True)
plt.show()


