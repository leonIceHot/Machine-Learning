# -*- coding: utf-8 -*-
"""
Created on Fri Aug  9 19:11:07 2019

@author: USER
"""

import pandas as pd
import numpy as np

# Create a dataframe
df = pd.DataFrame(np.random.randn(5,3), 
                  index=['a','c','e','f','h'], 
                  columns =['one', 'two', 'three'])
df.loc['a', 'two'] = np.nan
print(df)

# Check the data to be nan(True) or not(False)
print('\n')
print(df.isnull())

# Replace nan with the value of zero
print('\n')
print(df.fillna(0))

# Apply a function to dataframe
print('\n')
print(df.apply(lambda x: x.max()-x.min()))

# Applymap a function
print('\n')
print(df.applymap(np.sqrt))

# Query data
s = pd.Series(np.arange(5), index=np.arange(5)[::-1], dtype ='int64')
print('\n')
print(s)
print(s.isin([2,4,6]))