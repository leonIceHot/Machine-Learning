# -*- coding: utf-8 -*-
"""
Created on Sun Aug  4 05:57:19 2019

@author: USER
"""

import matplotlib.pyplot as plt
import numpy as np

x = np.arange(-8, 8, 0.1)
f1 = 1/(1+np.exp(-x))
f2 = 2/(1+np.exp(-2*x))-1
f3 = np.maximum(0,x)
f4 = np.maximum(0.1*x, x)

y      = [f1, f2, f3, f4]
titles = ['f(x)=1/(1+exp(-x))', 'f(x)=tanh(x)',
          'f(x)=max(0,x)', 'f(x)=max(0.1x,x)']
labels = ['sigmoid', 'tanh', 'ReLU', 'PReLu']

fig, ax = plt.subplots()
fig.subplots_adjust(hspace=0.4, wspace=0.4)

for i in range(0,4):
    plt.subplot(2,2,i+1)
    plt.plot(x, y[i], label=labels[i]) 
    plt.xlabel('x')
    plt.ylabel('y')
    plt.grid()
    plt.legend(loc='upper left', shadow=True)
    plt.title(titles[i])
plt.show()
