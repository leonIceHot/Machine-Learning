#include <stdio.h>

int main(){	
	int val1 = 10;
	printf("Address of val1 is %x\n", &val1);
	val1 = 20;
	printf("Address of val1 is %x\n", &val1);
		
}
