# -*- coding: utf-8 -*-
"""
Created on Sat Jul 29 01:49:06 2017

@author: user
"""

def foo(bar):
    print('(2.1)Address of bar: {0:#x}'.format(id(bar)))
    bar = 'new value'
    print('(2.2)Address of bar: {0:#x}'.format(id(bar)))
    print (bar)    # >> 'new value'

answer_list = 'old value'
print('(1)Address of answer_list[]: {0:#x}'.format(id(answer_list)))
foo(answer_list)
print('(3)Address of answer_list[]: {0:#x}'.format(id(answer_list)))
print(answer_list) # >> 'old value'