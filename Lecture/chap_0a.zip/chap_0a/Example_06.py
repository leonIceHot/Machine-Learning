import copy
mx1 = [11, [22,23], 31]
mx2 = copy.copy(mx1)
mx3 = copy.deepcopy(mx1)

print("Original values of mx1, mx2, and mx3")
print(mx1); print(mx2); print(mx3); print()
for i in range(len(mx1)):
    print(id(mx1[i]), id(mx2[i]), id(mx3[i]), end='\n')
print()

mx1[0] = 57
print("After mx1[0] is set to be {}.".format(mx1[0]))
print(mx1); print(mx2); print(mx3); print()
for i in range(len(mx1)):
    print(id(mx1[i]), id(mx2[i]), id(mx3[i]), end='\n')
print()

mx2[1][1] = 95
print("After mx2[1][1] is set to be {}.".format(mx2[1][1]))
print(mx1); print(mx2); print(mx3); print()
for i in range(len(mx1)):
    print(id(mx1[i]), id(mx2[i]), id(mx3[i]), end='\n')
