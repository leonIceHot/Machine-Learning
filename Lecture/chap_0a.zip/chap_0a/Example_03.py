"""
    This example is aimed to show that it would be incorrect to say that 
    "mutable objects can change and immutable ones can't". 
"""

first_names = ['Fred', 'George', 'Bill']
last_names = ['Smith', 'Jones', 'Williams']
name_tuple = (first_names, last_names)
print('Before first_names is changed')
print(first_names, last_names)
print(name_tuple)

first_names.append('Igor')
print('After first_names is changed')
print(first_names, last_names)
print(name_tuple)

