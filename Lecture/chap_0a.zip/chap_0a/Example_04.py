"""
    By now, we can intuit how function calls work in Python. For the example 
    below, if you call foo(bar), it merely creates a binding within the scope 
    of foo to the object that the argument bar is bound to when the function 
    is called. If bar refers to a mutable object and foo changes its value, 
    then these changes will be visible outside of the scope of the function.
"""

def foo(bar):
    bar.append(42)
    print('(2)Address of bar: {0:#x}'.format(id(bar)))
    print(bar)    # >> [42]

answer_list = []
print('(1)Address of answer_list[]: {0:#x}'.format(id(answer_list)))
foo(answer_list)
print('(3)Address of answer_list[]: {0:#x}'.format(id(answer_list)))
print(answer_list)  # >> [42]
