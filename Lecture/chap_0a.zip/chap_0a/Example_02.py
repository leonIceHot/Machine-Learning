"""
     This example is used to demonstrate the assignment between names in 
     Python, in which the objects will not be created.
"""

some_guy = 'Fred'
one_name = []
one_name.append(some_guy)
print("Address of some_guy is {0:#x}".format(id(some_guy)))
print("Address of one_name is {0:#x}".format(id(one_name)))

another_name = one_name
another_name.append('George')
print("Address of another_name is {0:#x}".format(id(another_name)))

some_guy = 'Bill'
print("Now, address of some_guy is {0:#x}".format(id(some_guy)))
print (some_guy, one_name, another_name)
