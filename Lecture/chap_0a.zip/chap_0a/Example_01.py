""" 
    In Python, (almost) everything is an object. What we commonly refer 
    to as "variables" in Python are more properly called names. Likewise, 
    "assignment" is really the binding of a name to an object. Each 
    binding has a scope that defines its visibility, usually the block 
    in which the name originates.

    This example is used to demonstrate how a name is bound to a string 
    object in Python.
"""

str1 = 'James Bond'
print("Address of 'James Bond' is {0:#x}".format(id('James Bond')))
print("Address of str1 is {0:#x}".format(id(str1)))
print()

str1 = 'Daniel Craig'
print("Address of 'Daniel Craig' is {0:#x}".format(id('Daniel Craig')))
print("Address of str1 is {0:#x}".format(id(str1)))
    

str1 = 4+3j
print("Address of 4+3j is {0:#x}".format(id(4+3j)))
print("Address of str1 is {0:#x}".format(id(str1)))    
    