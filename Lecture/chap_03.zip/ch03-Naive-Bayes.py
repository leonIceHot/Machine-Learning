import csv
import math
import random

# Step 1: Handle Data
def loadCsv(filename):
    lines   = csv.reader(open(filename))
    data    = list(lines)
    dataset = []
    for i in range(1, len(data)):
        dataset.append([float(x) for x in data[i]])
    return dataset

# To split the data into training and testing dataset
def splitDataset(dataset, splitRatio):
    trainSize = int(len(dataset) * splitRatio)
    trainSet = []
    copy = list(dataset)
    while len(trainSet) < trainSize:
        index = random.randrange(len(copy))
        trainSet.append(copy.pop(index))
    return [trainSet, copy]  # copy is testing dataset.

# Step 2: Summarize the Data
# Separate Data By Class
def separateByClass(dataset):
    separated = {}
    for i in range(len(dataset)):
        vector = dataset[i]
        if (vector[-1] not in separated):
            separated[vector[-1]] = []
        separated[vector[-1]].append(vector)
    return separated

# Calculate Mean
def mean(numbers):
    return sum(numbers)/float(len(numbers))    

# Calculate Standard Deviation
def stdev(numbers):
    avg = mean(numbers)
    variance = sum([pow(x-avg,2) for x in numbers])/float(len(numbers)-1)
    return math.sqrt(variance)

# Summarize Dataset
def summarize(dataset):
    summaries = [(mean(attribute), stdev(attribute)) for attribute in zip(*dataset)]
    del summaries[-1]
    return summaries

# Summarize Attributes By Class
def summarizeByClass(dataset):
    separated = separateByClass(dataset)
    summaries = {}
    for classValue, instances in separated.items():
        summaries[classValue] = summarize(instances)
    return summaries

# Step 3: Making Predictions
# Calculate Gaussian Probability Density Function
def calculateProbability(x, mean, stdev):
    exponent = math.exp(-(math.pow(x-mean,2)/(2*math.pow(stdev,2))))
    return (1/(math.sqrt(2*math.pi)*stdev))*exponent 

# Calculate Class Probabilities
def calculateClassProbabilities(summaries, inputVector):
    probabilities = {}
    for classValue, classSummaries in summaries.items():
        probabilities[classValue] = 1
        for i in range(len(classSummaries)):
            mean, stdev = classSummaries[i]
            x = inputVector[i]
            probabilities[classValue] *= calculateProbability(x, mean, stdev)
    return probabilities    

# Make a Prediction
def predict(summaries, inputVector):
    probabilities = calculateClassProbabilities(summaries, inputVector)
    bestLabel, bestProb = None, -1
    for classValue, probability in probabilities.items():
        if bestLabel is None or probability > bestProb:
            bestProb = probability
            bestLabel = classValue
    return bestLabel

# Make Predictions
def getPredictions(summaries, testSet):
    predictions = []
    for i in range(len(testSet)):
        result = predict(summaries, testSet[i])
        predictions.append(result)
    return predictions

# Step 4: Evaluate Accuracy
# Get Accuracy
def getAccuracy(testSet, predictions):
    correct = 0
    for x in range(len(testSet)):
        if testSet[x][-1] == predictions[x]:
            correct += 1
    return (correct/float(len(testSet)))*100.0


def main():
    fileName = 'C:/Users/USER/Dropbox/[1]教學/■Tensorflow應用設計-人工智慧/' \
               '2019-機器學習與資料採礦/chap_03/pima-indians-diabetes.csv'
    splitRatio = 0.67
    
    # Step 1: Handle Data
    dataset = loadCsv(fileName)
    trainingSet, testSet = splitDataset(dataset, splitRatio)
    print('Split {0} rows into train = {1} and test = {2} rows'.format( \
            len(dataset),len(trainingSet),len(testSet)))
    
    # Step 2: Summarize the Data
    summaries = summarizeByClass(trainingSet)
    
    # Step 3: Making Predictions
    predictions = getPredictions(summaries, testSet)
    
    # Step 4: Evaluate Accuracy
    accuracy    = getAccuracy(testSet, predictions)
    print('Accuracy: {0:.2f}%'.format(accuracy))

if __name__ == "__main__":
    main()
