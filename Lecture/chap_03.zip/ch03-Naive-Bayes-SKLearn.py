# Importing Libraries and Loading Datasets
import random
import csv
from sklearn import metrics
from sklearn.naive_bayes import GaussianNB

def loadCsv(filename):
    lines   = csv.reader(open(filename))
    data    = list(lines)
    dataset = []
    for i in range(1, len(data)):
        dataset.append([float(x) for x in data[i]])
    return dataset

# To split the data into training and testing dataset
def splitDataset(dataset, splitRatio):
    trainSize = int(len(dataset) * splitRatio)
    trainSet = []
    copy = list(dataset)
    while len(trainSet) < trainSize:
        index = random.randrange(len(copy))
        trainSet.append(copy.pop(index))
    return [trainSet, copy]  # copy is testing dataset.

# To split the dataset into data and label
def splitDataLabel(dataset):
    data  = []
    label = []
    for i in range(len(dataset)):
        label.append(dataset[i].pop())
        data.append([x for x in dataset[i]])
    return data, label


def main():
    fileName = 'C:/Users/USER/Dropbox/[1]教學/■Tensorflow應用設計-人工智慧/' \
               '2019-機器學習與資料採礦/chap_03/pima-indians-diabetes.csv'
    splitRatio = 0.67
    
    dataset = loadCsv(fileName)
    trainingSet, testSet = splitDataset(dataset, splitRatio)
    print('Split {0} rows into train = {1} and test = {2} rows'.format( \
            len(dataset),len(trainingSet),len(testSet)))
    trainX, trainY = splitDataLabel(trainingSet)
    testX, testY   = splitDataLabel(testSet)
    
    # Creating our Naive Bayes Model using Sklearn
    model = GaussianNB()
    model.fit(trainX, trainY)
    
    # Making Predictions
    expected = testY
    predicted = model.predict(testX)
    
    # Getting Accuracy and Statistics
    print(metrics.classification_report(expected, predicted))
    print(metrics.confusion_matrix(expected, predicted))

if __name__ == "__main__":
    main()
